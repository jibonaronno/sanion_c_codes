#!/bin/sh

cd /sys/bus/platform/drivers/omap-rproc;

echo 40800000.dsp > bind;

